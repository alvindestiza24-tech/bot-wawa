const _sessions = new Map()
const MAX_HISTORY = 10
const TTL_MS      = 30 * 60 * 1000

export function getHistory(userId) {
  const s = _sessions.get(userId)
  if (!s) return []
  if (Date.now() - s.ts > TTL_MS) { _sessions.delete(userId); return [] }
  s.ts = Date.now()
  return s.history
}

export function pushHistory(userId, role, content) {
  let s = _sessions.get(userId)
  if (!s || Date.now() - s.ts > TTL_MS) {
    s = { history: [], ts: Date.now() }
    _sessions.set(userId, s)
  }
  s.history.push({ role, content })
  if (s.history.length > MAX_HISTORY) s.history.splice(0, s.history.length - MAX_HISTORY)
  s.ts = Date.now()
}

export function clearHistory(userId) {
  _sessions.delete(userId)
}

export function sessionCount() {
  return _sessions.size
}