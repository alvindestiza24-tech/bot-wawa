export function parseAIResponse(rawText) {
  const components = {
    title: '',
    texts: [],
    codes: [],
    tables: [],
    suggests: [],
    footer: ''
  }

  let text = rawText.trim()
  if (text.startsWith('```json')) text = text.slice(7)
  if (text.startsWith('```'))     text = text.slice(3)
  if (text.endsWith('```'))       text = text.slice(0, -3)

  const codeBlockRegex = /```(\w+)?\n([\s\S]*?)```/g
  let codeMatch
  let tempText = text

  while ((codeMatch = codeBlockRegex.exec(text)) !== null) {
    const lang = codeMatch[1] || 'text'
    const code = codeMatch[2].trimEnd()
    components.codes.push({ lang: lang, code: code })
    tempText = tempText.replace(codeMatch[0], '')
  }

  const tableRegex = /^\|(.+)\|\n\|[-| ]+\|\n((?:\|.+\|\n?)+)/gm
  let tableMatch
  while ((tableMatch = tableRegex.exec(tempText)) !== null) {
    const headerCells = tableMatch[1].split('|').map(function(s) { return s.trim() })
    const rows = tableMatch[2].trim().split('\n').map(function(row) {
      return row.split('|').filter(function(c) { return c.trim() !== '' }).map(function(s) { return s.trim() })
    })
    components.tables.push([headerCells].concat(rows))
    tempText = tempText.replace(tableMatch[0], '')
  }

  const cleanText = tempText
    .replace(/\*\*(.*?)\*\*/g, '*$1*')
    .replace(/__(.*?)__/g, '*$1*')
    .replace(/\*(.*?)\*/g, '_$1_')
    .replace(/~~(.*?)~~/g, '~$1~')
    .replace(/`(.*?)`/g, '```$1```')
    .trim()

  const headingMatch = cleanText.match(/^#\s+(.+)/m)
  if (headingMatch) {
    components.title = headingMatch[1]
    components.texts = cleanText.replace(headingMatch[0], '').split('\n\n').filter(Boolean)
  } else {
    components.texts = cleanText.split('\n\n').filter(Boolean)
  }

  const suggestions = cleanText.match(/(?:^|\n)[-*]\s+(.+)/g)
  if (suggestions && suggestions.length <= 5) {
    components.suggests = suggestions.map(function(s) { return s.replace(/^[-*]\s+/, '').trim() })
  }

  return components
}