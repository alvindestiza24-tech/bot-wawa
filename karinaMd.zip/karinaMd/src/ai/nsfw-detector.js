/**
 * src/ai/nsfw-detector.js
 *
 * Fitur:
 *  - 5 Groq API key dengan rotasi otomatis (round-robin)
 *  - Fallback model chain untuk vision
 *  - Key 429 → cooldown 60 detik, lompat ke key berikutnya
 *  - Key 401 → skip 24 jam
 *  - Model 400 → fallback model berikutnya
 *  - Size check buffer sebelum kirim
 *  - Video di-skip (Groq Vision hanya support image)
 */

import axios  from 'axios'
import logger from '../lib/logger.js'

// ── Groq API Keys ─────────────────────────────────────────────────────────────

const GROQ_KEYS = [
  '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',  // key 1
  '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',  // key 2
  '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',  // key 3
  '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',  // key 4
  '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',  // key 5
].filter(k => k && !k.includes('xxx'))

// ── Model fallback chain (vision) ─────────────────────────────────────────────

const MODEL_CHAIN = [
  'meta-llama/llama-4-scout-17b-16e-instruct',  // utama — vision terbaru
  'llama-3.2-11b-vision-preview',               // fallback 1
  'llama-3.2-90b-vision-preview',               // fallback 2
]

// ── Konfigurasi ───────────────────────────────────────────────────────────────

const TIMEOUT_MS        = 20_000
const RATE_LIMIT_MS     = 2_000
const MIN_CONFIDENCE    = 0.7
const MAX_BUFFER_BYTES  = 4 * 1024 * 1024  // 4MB
const KEY_COOLDOWN_MS   = 60_000

// ── State ─────────────────────────────────────────────────────────────────────

let currentKeyIdx   = 0
let currentModelIdx = 0
let lastCallTime    = 0

const keyCooldown = new Map()

// ── System prompt ─────────────────────────────────────────────────────────────

const SYSTEM_PROMPT = `You are a strict NSFW image classifier for a WhatsApp group moderation bot.
Analyze the image and classify it. Respond ONLY with valid JSON. No markdown, no explanation outside JSON.

JSON Schema:
{
  "is_nsfw": boolean,
  "confidence": number (0.0 to 1.0),
  "label": "safe" | "suggestive" | "explicit" | "violent" | "other",
  "reason": "brief reason in Indonesian (max 10 words)"
}

Rules:
- Nudity or sexual content → is_nsfw: true, label: "explicit"
- Suggestive/sexy but not explicit → is_nsfw: true, label: "suggestive", confidence < 0.85
- Violence, gore, self-harm → is_nsfw: true, label: "violent"
- Normal everyday images → is_nsfw: false, label: "safe"
- When unsure → is_nsfw: false, confidence < 0.7`

// ── Key rotation ──────────────────────────────────────────────────────────────

function getActiveKey() {
  if (GROQ_KEYS.length === 0) throw new Error('Tidak ada Groq API key yang dikonfigurasi')

  const now = Date.now()

  for (let i = 0; i < GROQ_KEYS.length; i++) {
    const idx      = (currentKeyIdx + i) % GROQ_KEYS.length
    const cooldown = keyCooldown.get(idx) || 0
    if (now >= cooldown) {
      currentKeyIdx = idx
      return { key: GROQ_KEYS[idx], idx }
    }
  }

  // Semua cooldown — pakai yang paling cepat selesai
  let minTs  = Infinity
  let minIdx = 0
  for (const [idx, ts] of keyCooldown.entries()) {
    if (ts < minTs) { minTs = ts; minIdx = idx }
  }

  const waitMs = Math.max(0, minTs - now)
  logger.warn('NSFW', `Semua key cooldown, tunggu ${(waitMs / 1000).toFixed(1)}s...`)
  return { key: GROQ_KEYS[minIdx], idx: minIdx, waitMs }
}

function markKeyCooldown(idx, durationMs = KEY_COOLDOWN_MS) {
  keyCooldown.set(idx, Date.now() + durationMs)
  currentKeyIdx = (idx + 1) % GROQ_KEYS.length
  logger.warn('NSFW', `Key #${idx + 1} cooldown ${durationMs / 1000}s, switch ke key #${currentKeyIdx + 1}`)
}

function rotateKey() {
  currentKeyIdx = (currentKeyIdx + 1) % GROQ_KEYS.length
}

// ── Model rotation ────────────────────────────────────────────────────────────

function getCurrentModel() {
  return MODEL_CHAIN[currentModelIdx] || MODEL_CHAIN[0]
}

function fallbackModel() {
  if (currentModelIdx < MODEL_CHAIN.length - 1) {
    currentModelIdx++
    logger.warn('NSFW', `Switch model → ${MODEL_CHAIN[currentModelIdx]}`)
    return true
  }
  logger.error('NSFW', 'Semua model vision sudah dicoba')
  return false
}

function resetModel() {
  currentModelIdx = 0
}

// ── Groq Vision API call ──────────────────────────────────────────────────────

async function callGroqVision(base64Image, mimeType, depth = 0) {
  const maxDepth = GROQ_KEYS.length * MODEL_CHAIN.length
  if (depth >= maxDepth) throw new Error('Semua kombinasi key+model sudah dicoba')

  const { key, idx, waitMs } = getActiveKey()
  if (waitMs > 0) await new Promise(r => setTimeout(r, waitMs))

  try {
    const res = await axios.post(
      'https://api.groq.com/openai/v1/chat/completions',
      {
        model:       getCurrentModel(),
        temperature: 0.1,
        max_tokens:  200,
        messages: [
          { role: 'system', content: SYSTEM_PROMPT },
          {
            role:    'user',
            content: [
              {
                type:      'image_url',
                image_url: { url: `data:${mimeType};base64,${base64Image}` },
              },
              { type: 'text', text: 'Classify this image.' },
            ],
          },
        ],
      },
      {
        headers: {
          Authorization:  `Bearer ${key}`,
          'Content-Type': 'application/json',
        },
        timeout: TIMEOUT_MS,
      }
    )

    const raw = res.data?.choices?.[0]?.message?.content
    if (!raw) throw new Error('Respons kosong dari Groq')

    let clean = raw.trim()
    if (clean.startsWith('```json')) clean = clean.slice(7)
    if (clean.startsWith('```'))     clean = clean.slice(3)
    if (clean.endsWith('```'))       clean = clean.slice(0, -3)

    const parsed = JSON.parse(clean.trim())

    rotateKey()
    resetModel()

    return {
      is_nsfw:    Boolean(parsed.is_nsfw),
      confidence: Math.min(1, Math.max(0, Number(parsed.confidence) || 0)),
      label:      parsed.label  || 'safe',
      reason:     parsed.reason || '',
    }

  } catch (err) {
    const status = err.response?.status

    if (status === 429) {
      markKeyCooldown(idx)
      return callGroqVision(base64Image, mimeType, depth + 1)
    }

    if (status === 400) {
      logger.error('NSFW', `Model ${getCurrentModel()} error 400: ${JSON.stringify(err.response?.data)}`)
      if (fallbackModel()) return callGroqVision(base64Image, mimeType, depth + 1)
      throw new Error('Semua model vision gagal dengan error 400')
    }

    if (status === 401) {
      logger.error('NSFW', `Key #${idx + 1} tidak valid (401), skip`)
      markKeyCooldown(idx, 24 * 60 * 60 * 1000)
      return callGroqVision(base64Image, mimeType, depth + 1)
    }

    if (!status || status >= 500) {
      logger.warn('NSFW', `Server error ${status || 'network'}, retry...`)
      await new Promise(r => setTimeout(r, 1500))
      return callGroqVision(base64Image, mimeType, depth + 1)
    }

    logger.error('NSFW', `Unhandled error ${status}: ${err.message}`)
    throw err
  }
}

// ── Export utama ──────────────────────────────────────────────────────────────

export async function analyzeImage(buffer, mimeType = 'image/jpeg') {
  const now  = Date.now()
  const wait = RATE_LIMIT_MS - (now - lastCallTime)
  if (wait > 0) await new Promise(r => setTimeout(r, wait))
  lastCallTime = Date.now()

  try {
    if (!Buffer.isBuffer(buffer) || buffer.length === 0) {
      logger.warn('NSFW', 'Buffer kosong atau invalid')
      return null
    }

    if (buffer.length > MAX_BUFFER_BYTES) {
      logger.warn('NSFW', `Buffer terlalu besar (${(buffer.length / 1024 / 1024).toFixed(1)}MB), skip`)
      return null
    }

    const base64 = buffer.toString('base64')
    return await callGroqVision(base64, mimeType)

  } catch (err) {
    logger.error('NSFW', `Error analisis: ${err.message}`)
    return null
  }
}

export function shouldBlock(result) {
  if (!result) return false
  return result.is_nsfw === true && result.confidence >= MIN_CONFIDENCE
}

export function getStatus() {
  const now = Date.now()
  return {
    activeModel:  getCurrentModel(),
    modelIdx:     currentModelIdx,
    activeKeyIdx: currentKeyIdx,
    keys: GROQ_KEYS.map((_, i) => ({
      index:    i + 1,
      cooldown: keyCooldown.has(i)
        ? Math.max(0, Math.ceil((keyCooldown.get(i) - now) / 1000)) + 's'
        : 'ready',
    })),
  }
}